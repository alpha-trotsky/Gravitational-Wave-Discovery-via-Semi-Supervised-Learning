# `src/` — Source Overview

## Architecture in One Paragraph

The pipeline trains convolutional autoencoders on clean BBH inspiral signals (`h1_signal`) to learn a compact latent space, then uses that manifold as a signal detector / denoiser. Four model variants are implemented, all sharing the same CNN encoder/decoder backbone: a vanilla **CAE** baseline, a variance-based **HAE / VHAE** (penalises time-variance of `H`), a strictly conservative **ProperHAE** (enforces `ż = J ∇H`), and a dissipative **PortHAE** (enforces `ż = (J − R) ∇H`). Train/val/test splits are made by progenitor mass so that the held-out test set is OOD in mass. Evaluation measures reconstruction MSE, waveform overlap, latent PC1 ratio, noise robustness, and sweeps over `λ` (physics loss weight).

---

## File-by-File Reference

### `data.py`
Loads `output/dataset.hdf`, crops signals to a 1 792-sample inspiral window, normalises by the standard deviation of each sample's centre crop, and builds train/val/test `DataLoader`s.

**Key constants**
| Symbol | Value | Meaning |
|--------|-------|---------|
| `EVENT_IDX` | 11 264 | Merger sample index (5.5 s × 2 048 Hz) |
| `CROP_LEN` | 1 792 | Final sample length fed to models |
| `MAX_JITTER` | 256 | Training-time random time-shift (± 125 ms) |
| `WIDE_LEN` | 2 304 | Stored window that jitter draws from |

**Splits (mass-based)**
- Train: `mass1 ≤ 65 & mass2 ≤ 65`, 15 % random holdout → val
- Test:  `mass1 > 70 & mass2 > 65` (held-out mass region)
- Gap 65–70 M☉ is excluded from both

**Four loaders returned by `make_splits`**
- `train` — augmented (random jitter), shuffled
- `train_eval` — no jitter, no shuffle (for eval-mode train MSE)
- `val` — no jitter, no shuffle
- `test` — no jitter, no shuffle

**`GWDataset`** stores the wide window and slices the final `CROP_LEN` samples at `__getitem__` time. Both returned tensors are `(x, x)` (autoencoder: target = input).

---

### `models.py`
Defines the encoder, decoder, Hamiltonian MLP, all four model classes, and the two physics loss *functions* that require autograd.

#### Backbone
```
CNNEncoder : (B, 1, 1792) → Conv1d ×4 (strides 2) → 1×1 proj → (B, 2·D, 112)
CNNDecoder : (B, 2·D, 112) → 1×1 proj → ConvTranspose1d ×4 → (B, 1, 1792)
HamiltonianMLP : R^(2D) → Linear(64)→Tanh → Linear(64)→Tanh → Linear(1)
```
`D = latent_dim`, default 2. Latent shape `(B, 4, 112)`.

#### Model classes
| Class | `forward()` returns | `physics_type` |
|-------|---------------------|----------------|
| `BaselineCAE` | `(x_hat, z)` | — (no physics) |
| `VHAE` / `HAE` | `(x_hat, q, p, H_t)` | `'variance'` |
| `ProperHAE` | `(x_hat, q, p, H_t)` | `'proper'` |
| `PortHAE` | `(x_hat, q, p, H_t)` | `'port'` |

`HAE` is a backwards-compatible alias for `VHAE`.

#### Physics loss functions (in `models.py`)

**`proper_hnn_loss(hamiltonian_net, z, dt=1.0, create_graph=True)`**
Enforces conservative Hamiltonian mechanics.
1. Compute `ż_actual` via central finite differences over the latent trajectory.
2. Compute `∇_z H` via `torch.autograd.grad` through the Hamiltonian MLP.
3. Predict `ż_pred = J ∇H` where `J` is the symplectic matrix.
4. Loss = `MSE(ż_actual, ż_pred)`.

`create_graph=True` is required during training so the second-order gradient (through the physics constraint back to the encoder) can be computed by `.backward()`.

**`port_hamiltonian_loss(hamiltonian_net, R_matrix, z, dt=1.0, create_graph=True)`**
Same as above but with `ż_pred = (J − R) ∇H`, where `R = L Lᵀ` is the learned PSD dissipation matrix. Allows monotonic energy decay, appropriate for the inspiral chirp.

**`compute_latent_velocity(z, dt=1.0)`**
Central finite differences on the `(B, C, T)` latent tensor; forward/backward differences at boundaries.

---

### `losses.py`
Lightweight loss functions for the variance-based HAE variant.

| Function | Formula |
|----------|---------|
| `reconstruction_loss(x_hat, target)` | `F.mse_loss` |
| `hamiltonian_loss(H_t)` | `mean_batch( var_time(H_t) )` — zero for a perfectly conservative system |
| `total_hdae_loss(x_hat, target, H_t, λ)` | `recon + λ · phys` → returns `(total, recon, phys)` |

The variance penalty requires no second-order autograd — gradients flow only through the Hamiltonian MLP weights and the encoder outputs.

---

### `train.py`
Core training loop, early stopping, and checkpointing.

#### `_train_epoch(model, loader, optimizer, device, lambda_phys)`
Dispatches to the correct loss based on `model.physics_type` (set as a side-effect of `forward()`):
- `variance` / `else` → `total_hdae_loss` (no second-order grad)
- `proper` → `proper_hnn_loss` with `create_graph=True`
- `port` → `port_hamiltonian_loss` with `create_graph=True`

Gradient clipping at `max_norm=1.0` applied before every `optimizer.step()`.

#### `_val_epoch(model, loader, device, lambda_phys)`
Mirror of train epoch, but:
- `variance` / `else` branches: losses computed under `torch.no_grad()`
- `proper` / `port` branches: `model(x)` is called outside no_grad (needed to build the graph for `torch.autograd.grad`), then the physics metric is computed inside `torch.enable_grad()` with `create_graph=False`

#### `train_model(...)`
Full training run: Adam optimiser, early stopping on val reconstruction MSE, saves best weights to `{checkpoint_dir}/{model_name}_best.pt`.

#### `quick_train(...)`
Capped-epoch version for hyperparameter search (no checkpointing, no logging).

---

### `hparam_search.py`
Grid search over `lambda_phys ∈ {0.01, 0.1, 1.0}`, `latent_dim ∈ {1, 2, 4}`, `lr ∈ {1e-4, 1e-3}` using `quick_train` (50 epochs, patience 10). Results saved to `results/hparam_search.csv`. Returns best configs for HAE and CAE separately.

---

### `evaluate.py`
Six evaluation experiments, all writing plots to `./plots/` and metrics to `./results/final_metrics.json`.

| # | Experiment | Key metric |
|---|-----------|------------|
| 1 | Reconstruction quality | Test MSE, waveform overlap, PC1 ratio |
| 2 | Phase-space trajectories | Visual (q₀ vs p₀, or ch0 vs ch1 for CAE) |
| 3 | Generalisation bar chart | Train vs test MSE (held-out mass range) |
| 4 | Loss curves | Train/val MSE and physics loss per epoch |
| 5 | Noise robustness | OOD MSE/overlap with whitened noisy `h1_strain` |
| 6 | Lambda sweep | Test MSE / overlap / PC1 vs `λ ∈ {0.01, 0.1, 1.0}` |

**`_collect_outputs`** dispatches on `isinstance(model, HAE)` to handle the `(x_hat, z)` vs `(x_hat, q, p, H_t)` return shapes.

**PC1 ratio**: fraction of latent variance explained by PC1 of a single trajectory. Higher = more 1D-like = more constrained manifold, which is physically desirable for an inspiral.

---

### `main.py`
CLI entry point. Stages: hparam search → train → evaluate → lambda sweep. All use `HAE` (= VHAE) and `BaselineCAE`.

```
python src/main.py --run-all           # full pipeline
python src/main.py --no-hparam         # skip grid search, use defaults
python src/main.py --train             # train only (loads saved configs)
python src/main.py --evaluate          # evaluate only (loads checkpoints)
python src/main.py --lambda-sweep      # sweep λ only
```

Default configs: `lambda_phys=0.1, latent_dim=2, lr=1e-3` for HAE; `latent_dim=2, lr=1e-3` for CAE.

---

### `run_physics_variants.py`
Trains `ProperHAE` and `PortHAE` across `λ ∈ {0.1, 0.5, 1.0}`, reading best `latent_dim` and `lr` from `results/best_configs.json`. Uses the same `train_model` loop as `main.py`.

### `compare_physics_models.py`
Evaluation-only script. Loads checkpoints for all four model types (HAE, CAE, ProperHAE, PortHAE) and reports test MSE / overlap / PC1. Defines its own `collect_outputs` that handles both 2-tuple and 4-tuple `forward()` returns.

### `regenerate_*.py`
Standalone plot-regeneration scripts — `regenerate_plots.py`, `regenerate_reconstructions.py`, `regenerate_phase_space_2x2.py` — that load existing checkpoints and re-render figures without re-training.

---

## Data Flow Summary

```
dataset.hdf
   ├── injection_parameters/h1_signal  →  GWDataset  →  train/val/test loaders
   └── injection_samples/h1_strain     →  load_noisy_test_data (eval only)

Loaders → train_model
   └── _train_epoch
         ├── BaselineCAE  →  reconstruction_loss only
         ├── VHAE/HAE     →  total_hdae_loss (recon + λ · var(H_t))
         ├── ProperHAE    →  recon + λ · proper_hnn_loss  (∇²-autograd)
         └── PortHAE      →  recon + λ · port_hamiltonian_loss  (∇²-autograd)

Checkpoints → evaluate.py → plots/ + final_metrics.json
```

---

## Known Issues and Bugs

### Bug 1 — Double Hamiltonian computation in `ProperHAE` / `PortHAE` (Significant)

**Location:** `models.py:281-286` (ProperHAE.forward), `models.py:323-328` (PortHAE.forward); `train.py:43-50`, `train.py:97-107`

`ProperHAE.forward()` and `PortHAE.forward()` compute `H_flat = self.hamiltonian(z_flat)` to populate `H_t` in the return tuple. But `_train_epoch` and `_val_epoch` for `'proper'`/`'port'` types **ignore `H_t`** and call `proper_hnn_loss` / `port_hamiltonian_loss`, which call `hamiltonian_net(z_flat)` again internally. The Hamiltonian MLP is therefore called **twice** on the same input every forward pass. Both calls build a computation graph; the first one is discarded.

Fix: have `ProperHAE.forward()` and `PortHAE.forward()` return a sentinel `H_t = None` (or just remove the H computation from their `forward()`), and let the physics loss functions be the sole callers of the Hamiltonian MLP.

---

### Bug 2 — `physics_type` set as a side-effect in `forward()` (Fragility / Design)

**Location:** `models.py:256` (VHAE), `models.py:290` (ProperHAE), `models.py:334` (PortHAE)

```python
self.physics_type = 'proper'   # set inside forward()
```

`physics_type` is not set in `__init__()`. Any code that reads `model.physics_type` before the first `forward()` call raises `AttributeError`. The training loop reads it immediately after `model(x)` returns (so it currently works), but the design is fragile.

Fix: set `self.physics_type = 'proper'` in each class's `__init__`.

---

### Bug 3 — Unnecessary autograd graph built in `_val_epoch` for variance/CAE branches (Memory waste)

**Location:** `train.py:85` (`out = model(x)` outside any `no_grad` context)

`out = model(x)` is called unconditionally (no `torch.no_grad()` wrapper). For the `'variance'` and `else`/CAE branches the entire backward graph is immediately abandoned after `.item()` is called. This holds GPU/CPU memory unnecessarily for every validation batch of non-physics-gradient models.

Fix: restructure so that `model(x)` is called inside `torch.no_grad()` when the branch doesn't need autograd (variance, CAE), and outside it only for `proper`/`port`.

---

### Bug 4 — `evaluate.py._collect_outputs` crashes on `ProperHAE` / `PortHAE` (Functional)

**Location:** `evaluate.py:50-54`

```python
if isinstance(model, HAE):          # HAE == VHAE only
    x_hat, q, p, _ = model(x)
    z = torch.cat([q, p], dim=1)
else:
    x_hat, z = model(x)             # ValueError: too many values to unpack
```

`ProperHAE` and `PortHAE` both return a 4-tuple but are not subclasses of `HAE`/`VHAE`, so they fall into the `else` branch and cause a `ValueError`. `compare_physics_models.py` correctly handles this with its own `collect_outputs`, but any call from `evaluate.py` to these models will crash.

Fix: change the dispatch condition to `len(out) == 4` (matching the pattern used in `train.py`) or check `isinstance(model, (HAE, ProperHAE, PortHAE))`.

---

### Minor Note — `_val_epoch` holds the full graph for `proper`/`port` during the loop body

For proper/port models, `model(x)` must be called outside `no_grad` (needed to compute `torch.autograd.grad`). This is intentional and correct, but means every validation batch briefly holds the full backward graph in memory before the physics gradient call frees it with `retain_graph=False`. This is unavoidable given the current design, but worth being aware of when profiling memory on large batches.
